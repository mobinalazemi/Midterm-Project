public class Black {

    public static String reverse(String string) {
        char temp;
        String s = "";
        for (int i = 0; i < string.length(); i++) {
            temp = string.charAt(string.length() - (i + 1));
            s += temp;
        }
        return s;


    public static String doubleWords(String string) {
        char temp;
        char temp1;
        String s = "";
        for (int i = 0; i < string.length(); i++) {
            temp = string.charAt(i);
            temp1 = string.charAt(i);
            s += temp;
            s += temp1;
        }
        return s;
    }

    public static String doubleString(String string){
        return s + s;
    }

    public static String shiftString(String string){
        char temp;
        String s = "";
        s += string.charAt(string.length() - 1);
        for (int i = 0; string.length()-1 > i; i++) {
            temp = string.charAt(i);
            s += temp;
        }
        return s;
    }

    public static String returnString(String string){
        String s = "";
        int temp;
        char tempChar;
        int[] tempArr = new int[26];
        int counter = 122;
        for (int i = 0; i < 26; i++) {
            tempArr[i] = counter;
            counter--;
        }
        for (int i = 0; i < string.length(); i++) {
            temp = string.charAt(i);
            for (int j = 0; j < tempArr.length; j++) {
                if (temp == tempArr[j]) {
                    temp = Math.abs(tempArr[25 - j]);
                    break;
                }
            }
            tempChar = (char)temp;
            s += tempChar;
        }
        return s;
    }
}