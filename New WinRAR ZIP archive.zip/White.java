//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class White{

    public static String reverseSum(String string1 , String string2){
        char temp;
        String string = "";
        for (int i = 0; i < string2.length(); i++){
            temp = string2.charAt(string2.length() - (i+1));
            string += temp;
        }
        return string1 + string;
    }

    public static String evenString(String string1 , String string2){
        if (string1.length() % 2 == 0){
            return string1;
        }
        else{
            return string2;
        }
    }

    public static String sumString(String string1 , String string2){
        char temp;
        char temp1;
        String string = "";
        if (string1.length() > string2.length()){
            int d = string1.length() - string2.length();
            for (int i = 0; i < string2.length(); i++){
                temp = string1.charAt(i);
                temp1 = string2.charAt(i);
                string += temp;
                string += temp1;
            }
            for (int i = string2.length(); i < string1.length(); i++){
                temp = string1.charAt(i);
                string += temp;
            }
            return string;
        }
        else{
            int d = string2.length() - string1.length();
            for (int i = 0; i < string1.length(); i++){
                temp = string1.charAt(i);
                temp1 = string2.charAt(i);
                string += temp;
                string += temp1;
            }
            for (int i = string1.length(); i < string2.length(); i++){
                temp1 = string2.charAt(i);
                string += temp1;
            }
            return string;
        }
    }

    public static String decussateString(String string1 , String string2){
        char temp;
        String str = "";
        for (int i = 0; i < string2.length(); i++){
            temp = string2.charAt(string2.length() - (i+1));
            str += temp;
        }
        char temp1;
        char temp2;
        String str1 = "";
        if (string1.length() > str.length()){
            int d = string1.length() - str.length();
            for (int i = 0; i < str.length(); i++){
                temp1 = string1.charAt(i);
                temp2 = str.charAt(i);
                str1 += temp1;
                str1 += temp2;
            }
            for (int i = str.length(); i < string1.length(); i++){
                temp1 = string1.charAt(i);
                str1 += temp1;
            }
            return str1;
        }
        else{
            int d = str.length() - string1.length();
            for (int i = 0; i < string1.length(); i++){
                temp1 = string1.charAt(i);
                temp2 = str.charAt(i);
                str1 += temp1;
                str1 += temp2;
            }
            for (int i = string1.length(); i < str.length(); i++){
                temp2 = str.charAt(i);
                str1 += temp2;
            }
            return str1;
        }

        public static String combineString(String string1 , String string2){
            StringBuilder srtiing = new StringBuilder();
            int min = Math.min(string1.length() , string2.length());
            for (int i = 0; i < min; i++) {
                char char1 = string1.charAt(i);
                char char2 = string2.charAt(i);
                int sum = (char1 - 'a' + char2 - 'a') % 26 + 'a';
                srtiing.append((char) sum);
            }
            if (string1.length() > string2.length()) {
                srtiing.append(string1.substring(string2.length()));
            }
            else if (string2.length() > string1.length()) {
                striing.append(string2.substring(string1.length()));
            }
            return striing.toString();
        }
    }

}